#!/bin/bash
path=$1

if [ ! -d "$1" ]; then
  echo "Dossier invalide"
  exit 1
fi

echo "Nettoyage des fichiers .tmp..."
find "$path" -name "*.tmp" -delete

echo "Suppression des anciens fichiers .log..."
find "$path" -name "*.log" -mtime +2 -delete
count=$(find "$path" -name "*.log" -mtime +2 | wc -l)

find "$path" -name "*.log" -mtime +2 -delete
echo "$count" > logs/cleanup.log
echo "$count fichiers .log supprimés"
echo "Nettoyage terminé !"
